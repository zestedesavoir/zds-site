Nous sommes arrivé à la fin de la troisième partie et j'ai une bonne nouvelle pour vous : vous avez toutes les bases pour créer un site dynamique et efficace avec C# et ASP.NET MVC.

Il restera néanmoins beaucoup de choses à découvrir pour améliorer les performances et les fonctionnalités de votre site.