Nous allons coder notre application grâce à l'approche **code first**. 
L'avantage c'est que nous avons déjà codé une partie de nos modèles, il n'y aura plus qu'à les intégrer à entity framework.