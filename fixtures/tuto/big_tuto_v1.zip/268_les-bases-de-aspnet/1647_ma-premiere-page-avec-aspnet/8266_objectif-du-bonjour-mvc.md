Pour commencer ce tutoriel dans de bonnes conditions, l'objectif ici est de réaliser un très petite application Web afin d'intégrer la notion de Modèle-Vue-Contrôleur. Nous l'avons nommé **BonjourMVC**.

Dans cette application, le visiteur rentrera son nom dans un champ de texte modifiable et lorsqu'il cliquera sur le bouton Valider, nous lui afficherons "Bonjour" suivit de sa saisie. Voici la maquette de notre objectif.

![BonjourMVC, notre première application](/media/galleries/304/a6153b8b-37cb-48e5-af0a-e0d443e3336f.png.960x960_q85.png)

Ca à l'air simple comme cela, mais nous vous assurons que c'est déjà du travail !