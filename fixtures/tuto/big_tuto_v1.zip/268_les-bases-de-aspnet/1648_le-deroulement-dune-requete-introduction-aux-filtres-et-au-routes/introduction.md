En ASP.NET, la notion de **filtre** et de **route** est importante pour comprendre comment va fonctionner notre application.
Dans le chapitre de l'application HelloMVC, nous avons utilisé ces deux notions, peut-être sans nous en rendre compte.
Pour la suite, il est préférable de commencer à connaître les bases des filtres et des routes.

Les filtres sont des attributs personnalisés qui fournissent un moyen déclaratif pour ajouter un comportement pré et post-action aux méthodes d'action de contrôleur.
Les routes, à partir d'une URL, vont déterminer quel contrôleur appeler et avec quels arguments.