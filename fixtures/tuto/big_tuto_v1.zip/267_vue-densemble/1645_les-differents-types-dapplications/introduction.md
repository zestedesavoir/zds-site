ASP.NET est un framework très complet et très souple.

Sa force, c'est son intégration au monde Windows, ce qui lui permet d'accéder à des fonctionnalités telles qu'Active Directory très facilement.

Par soucis d'être en phase avec les technologies les plus modernes du Web tout en vous permettant de développer **rapidement** vos applications, Visual Studio intègre plusieurs modèles de projets que nous avons brièvement découvert lors du chapitre précédent.

[[information]]
| Nous employons le mot "modèle" pour décrire un projet créé avec Visual Studio. Sachez qu'il est normalement employé dans sa version anglaise : **Template**. Ainsi nous dirons Template de projet.

Ces *templates* permettent de partir sur des bases saines pour différents types d'applications, de technologies.

Ce chapitre montre les différentes possibilités. Lorsque cela s'y prête, une courte démonstration vidéo vous est proposée.