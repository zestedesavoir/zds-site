|Vous vous doutes bien qu'il existe de ce fait deux autre "Patterns", nous le verrons plus tard. Je vous conseille néanmoins d'utiliser le TAP.

