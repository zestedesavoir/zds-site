
- Configurez le contexte pour que par défaut il s'exécute sur plusieurs thread sauf dans le cas d'une tâche que touche à l'UI.