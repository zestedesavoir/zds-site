
[[a]]
|Ce tutoriel vous sera particulièrement utile si vous faites des applications mobiles. Dès qu'une tâche demande d'attendre, les applications mobiles vous obligent à utiliser l'asynchrone.