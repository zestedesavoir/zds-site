
Si vous avez besoin d'aide, n'hésitez pas à poser vos questions sur le forum avec les tag [async][C#].



