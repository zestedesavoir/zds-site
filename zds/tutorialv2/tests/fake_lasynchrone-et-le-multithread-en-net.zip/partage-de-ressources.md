Vous noterez que la dépendance est passée de tâche en tâche et qu'à chaque fois la tâche parente aussi. 
